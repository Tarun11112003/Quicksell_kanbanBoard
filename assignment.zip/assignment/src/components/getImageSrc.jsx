function getImageSrc(parameter, value) {
    return '/icons/' + parameter + '/' + value + '.svg';
  }
  
  
  export default getImageSrc